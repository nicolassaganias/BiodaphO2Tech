This folder contains old DEPRECATED examples
that use an old interface that is only available
for Opta Digital for compatibility issues and will 
be soon no more available.
